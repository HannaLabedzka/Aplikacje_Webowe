__copyright__ = "Zespół Szkół Komunikacji"
__author__ = "Hanna Labedzka 4D"

class Teacher:

    def __init__(self, id, name, surname):
        self._id = int(id)
        self.name = str(name)
        self.surname = str(surname)

    def __str__(self):
        return f"{self.name} {self.surname}"
    
        
    
    