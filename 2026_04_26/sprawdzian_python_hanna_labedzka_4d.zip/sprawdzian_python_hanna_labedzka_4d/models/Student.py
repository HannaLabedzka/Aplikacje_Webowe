import datetime

__copyright__ = "Zespół Szkół Komunikacji"
__author__ = "Hanna Labedzka 4D"
class Student:
    def __init__(self, id, first_name, last_name, birth_date):
        self._id = int(id)
        self.first_name = str(first_name)
        self.last_name = str(last_name)
        self.birth_date = birth_date
        

    @property
    def age(self): 
        #Metoda powinna być dostępna jako pole klasy (użyj dekoratora property)
        actual_year = datetime.datetime.now().year
        birth_year = self.birth_date.year
        return actual_year-birth_year
    
    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.age})"
