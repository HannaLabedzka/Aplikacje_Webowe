
import datetime, json
from Teacher import Teacher
from Subject import Subject
from Grades import Grades
from Student import Student

__copyright__ = "Zespół Szkół Komunikacji"
__author__ = "Hanna Labedzka 4D"

teachers = []
subjects = []
students = []
grades = []

students_data =[]

with open("teachers.txt") as plik:
    lista_1 = [x.strip() for x in plik]

for line in lista_1: 
    parts = line.split(" ")
    id = int(parts[0])
    name = str(parts[1])
    surname = str(parts[2])
    teachers.append(Teacher(id, name, surname))


with open("subjects.txt") as plik:
    lista_2 = [x.strip() for x in plik]

for line in lista_2: 
    parts = line.split(" ")
    id = int(parts[0])
    name = str(parts[1])
    teacher_id =int(parts[2])
    teacher = next((t for t in teachers if t._id == teacher_id), None)
    if teacher:
        subjects.append(Subject(id, name, teacher))


with open("students.txt") as plik:
    lista_3 = [x.strip() for x in plik]

for line in lista_3: 
    parts = line.split(" ")
    id = int(parts[0])
    name = str(parts[1])
    surname = str(parts[2])
    birth_date = datetime.datetime.strptime(parts[3], '%Y-%m-%d').date()
    students.append(Student(id, name, surname, birth_date))


with open("grades.txt") as plik:
    lista_4 = [x.strip() for x in plik]

for line in lista_4: 
    parts = line.split(" ")
    student_id = int(parts[0])
    subject_id = int(parts[1])
    grades_list = [int(x) for x in parts[2].split(",")]

    student = next((s for s in students if s._id == student_id), None)
    subject = next((s for s in subjects if s._id == subject_id), None)

    if student and subject:
        g = Grades(student, subject)
        for grade in grades_list:
            g.add_grade(grade)
        grades.append(g)


print("Oceny i srednie poszczegolnych uczniow")

for student in students:

    student_d = {}
    subjects_d = {}

    print(student)

    student_grades = [g for g in grades if g.student == student]
    for g in student_grades:
        print(g.subject.name, ":")
        
        grades_str = ", ".join(str(x) for x in g.get_grades())
        print("  Oceny:", grades_str)
        
        avg = round(g.get_average(), 2)
        final = g.get_year_grade(avg)
        print("  Srednia: ", avg)
        print("  Ocena koncowa: ",final)


        subjects_d[g.subject.name]={
            "Oceny": grades_str,
            "Srednia":avg,
            "Ocena koncowa": final
        }

    student_d[str(student)] = subjects_d
    students_data.append(student_d)
    
    print()
    
with open("students.json", "w", encoding="utf-8") as wynik:
        json.dump(students_data, wynik, ensure_ascii=False, indent=4)

print("="*50)
print()

subjects_data = []
for subject in subjects:
    subject_dic = {}
    print(subject.name)
    print(" Nauczyciel: ", subject.teacher)

    subject_grades = [g for g in grades if g.subject == subject]
    grades_str = ""
    avg_stu = 0

    for g in subject_grades:
        grades_str += ", ".join(str(x) for x in g.get_grades()) + ", "
        avg_stu += round(g.get_average(), 2)
         
    oceny = grades_str.rstrip(", ")
    print("  Oceny: ", oceny)
    avg_sub = round(avg_stu/3, 2) #jest 3 uczniow
    print("  Srednia: ", avg_sub)
    print()

    nauczyciel = subject.teacher.name +" "+ subject.teacher.surname

    subject_dic[subject.name] = {
        "Nauczyciel": nauczyciel,
        "Oceny" : oceny, 
        "Srednia": avg_sub
    }

    subjects_data.append(subject_dic)


with open("subjects.json", "w", encoding="utf-8") as wynik_sub:
    json.dump(subjects_data, wynik_sub, ensure_ascii=False, indent=4)









    




