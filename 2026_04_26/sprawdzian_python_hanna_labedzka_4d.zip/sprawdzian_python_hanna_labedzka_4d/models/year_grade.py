__copyright__ = "Zespół Szkół Komunikacji"
__author__ = "Hanna Labedzka 4D"

def year_grade(average): #average w postaci float

    x=0
    if average>=5.5 : 
        x = 6
    elif average>=4.7 : 
        x = 5
    elif average>=3.7 : 
        x = 4
    elif average>=2.7 : 
        x = 3
    elif average>=1.85 : 
        x = 2
    elif average<1.85 : 
        x = 1
    else:
        x = 100

    return int(x)