from Teacher import Teacher
__copyright__ = "Zespół Szkół Komunikacji"
__author__ = "Hanna Labedzka 4D"
class Subject:
    
    def __init__(self, id, name, teacher):
        self._id = int(id)
        self.name = str(name)
        self.teacher = teacher #obiekt Teacher
    
    def __str__(self):
        return f"{self.name} {self.teacher}"
    
        