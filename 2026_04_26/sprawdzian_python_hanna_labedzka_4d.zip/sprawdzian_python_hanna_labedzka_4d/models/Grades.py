from Student import Student
from Subject import Subject
from year_grade import year_grade

__copyright__ = "Zespół Szkół Komunikacji"
__author__ = "Hanna Labedzka 4D"

class Grades:
    
    def __init__(self, student, subject):
        self.student = student
        self.subject = subject
        self.grades = []

    def add_grade(self, grade):
        if grade < 1 or grade >6:
            raise ValueError(f"Grade must be between 1 and 6")
        else:
            self.grades.append(grade)
            
    def get_grades(self):
        #lista liczb calkowitych grades
        return self.grades

    def get_average(self):
        return sum(self.grades)/len(self.grades)
    
    def get_year_grade(self, x):
        return int(year_grade(x))
        